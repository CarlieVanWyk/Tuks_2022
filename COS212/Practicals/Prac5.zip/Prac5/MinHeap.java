//carlie van wyk u21672823

@SuppressWarnings("unchecked")
public class MinHeap<T extends Comparable<T>> extends Heap<T> {

    public MinHeap(int capacity) {
	super(capacity);
    }

    ////// You may not change any code above this line //////

    ////// Implement the functions below this line //////

    @Override
    public void insert(T elem) {

        //Your code goes here
        //add to array:
        currentSize++;
        mH[currentSize] = elem;

        //restore array:
        while(mH[currentSize].compareTo((T) mH[currentSize/2]) < 0 ) {
            if (currentSize == 1) {
                //if elem added is the first node (root)
                // no restoring needed
                break;
            } else if (mH[currentSize].compareTo((T) mH[currentSize / 2]) < 0) {
                Comparable<T> temp = mH[currentSize];
                mH[currentSize] = mH[currentSize / 2];
                mH[currentSize / 2] = temp;
            } else {
                //do nothing cause child is smaller than parent
            }
        }
    }

    public T removeMin() {

        //Your code goes here
        return null;
    }

    public void delete(T elem) {

	//Your code goes here
    }


    //Helper functions


}